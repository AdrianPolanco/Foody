﻿

namespace Foody.Core.Domain.Enums
{
    public enum DishCategory
    {
        Starter = 1,
        MainCourse = 2,
        Dessert = 3,
        Drink = 4
    }
}
