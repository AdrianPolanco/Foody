﻿
namespace Foody.Core.Domain.Enums
{
    public enum OrderState
    {
        InProcess,
        Completed
    }
}
