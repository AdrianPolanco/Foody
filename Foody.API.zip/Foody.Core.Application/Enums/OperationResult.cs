﻿

namespace Foody.Core.Application.Enums
{
    public enum OperationResult
    {
        Success,
        Error,
        Invalid
    }
}
