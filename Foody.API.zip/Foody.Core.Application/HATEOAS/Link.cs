﻿namespace Foody.Core.Application.HATEOAS
{
    public record Link(string Href, string Rel, string Method);
}
