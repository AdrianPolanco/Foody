﻿

namespace Foody.Core.Domain.Enums
{
    public enum TableState
    {
        Available = 1,
        Attending = 2,
        Attended = 3
    }
}
