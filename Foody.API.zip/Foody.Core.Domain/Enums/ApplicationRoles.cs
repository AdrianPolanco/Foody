﻿

namespace Foody.Core.Domain.Enums
{
    public enum ApplicationRoles
    {
        Manager,
        Waiter,
        Owner 
    }
}
