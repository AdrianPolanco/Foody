﻿namespace Foody.Shared.Hateoas
{
    public class HateoasConstants
    {
        public const string SELF = "self";
        public const string SIGN_UP_ADMIN = "/admin";
        public const string SIGN_UP_WAITER = "/waiter";
        public const string LOGIN = "/auth";

    }
}
