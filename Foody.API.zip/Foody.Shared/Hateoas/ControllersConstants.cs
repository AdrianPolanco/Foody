﻿

namespace Foody.Shared.Hateoas
{
    public class ControllersConstants
    {
       public const string ACCOUNTS = "accounts";
       public const string INGREDIENTS = "ingredients";
       public const string DISHES = "dishes";
       public const string TABLES = "tables";
       public const string ORDERS = "orders";
    }
}
