﻿

namespace Foody.Core.Application.Interfaces.MediatR.CQRS
{
    public interface IResponse
    {
        public Guid Id { get; set; }
    }
}
